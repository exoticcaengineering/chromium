---
name: Feature Request
about: Suggest an Idea or Improvement
title: "[REQUEST]"
labels: enhancement
---

## What would you like to have implemented?

<!--- Clearly describe what feature you'd like to see implemented and why. -->

## Why would it be useful?

<!--- Optional: Provide any use cases, code or screenshots that support this feature request. -->
